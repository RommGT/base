-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: quiz_teams
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `open_graphs`
--

DROP TABLE IF EXISTS `open_graphs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `open_graphs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_question` int DEFAULT NULL,
  `url_graph` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_graphs`
--

LOCK TABLES `open_graphs` WRITE;
/*!40000 ALTER TABLE `open_graphs` DISABLE KEYS */;
INSERT INTO `open_graphs` VALUES (76,135,'http://localhost:3000/images/cloudResult135.png\r\n'),(77,135,'http://localhost:3000/images/cloudResult135.png\r\n'),(78,135,'http://localhost:3000/images/cloudResult135.png\r\n'),(79,136,'http://localhost:3000/images/cloudResult136.png\r\n'),(80,136,'http://localhost:3000/images/cloudResult136.png\r\n'),(81,136,'http://localhost:3000/images/cloudResult136.png\r\n'),(82,137,'http://localhost:3000/images/cloudResult137.png\r\n'),(83,137,'http://localhost:3000/images/cloudResult137.png\r\n'),(84,137,'http://localhost:3000/images/cloudResult137.png\r\n'),(85,139,'http://localhost:3000/images/cloudResult139.png\r\n'),(86,2,'http://localhost:3000/images/cloudResult2.png\r\n'),(87,5,'http://localhost:3000/images/cloudResult5.png\r\n'),(88,6,'http://localhost:3000/images/cloudResult6.png\r\n'),(89,7,'http://localhost:3000/images/cloudResult7.png\r\n'),(90,8,'http://localhost:3000/images/cloudResult8.png\r\n'),(91,9,'http://localhost:3000/images/cloudResult9.png\r\n'),(92,10,'http://localhost:3000/images/cloudResult10.png\r\n'),(93,11,'http://localhost:3000/images/cloudResult11.png\r\n');
/*!40000 ALTER TABLE `open_graphs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-03 10:13:27
