-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: quiz_teams
-- ------------------------------------------------------
-- Server version	8.3.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `open_answers`
--

DROP TABLE IF EXISTS `open_answers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `open_answers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `id_question` int DEFAULT NULL,
  `answer` text,
  `id_meeting` text,
  `email` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_answers`
--

LOCK TABLES `open_answers` WRITE;
/*!40000 ALTER TABLE `open_answers` DISABLE KEYS */;
INSERT INTO `open_answers` VALUES (1,2,'assa','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','undefined'),(2,5,'asassasa','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(3,5,'asas','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(4,5,'xaxsa','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(5,6,'holis','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(6,7,'assa','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(7,8,'asad','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(8,8,'cascs','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(9,8,'hola','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(10,8,'chao','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(11,8,'buenos dias','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(12,9,'CAX','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(13,9,'XASXA','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(14,9,'AASVDSVS','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(15,9,'SDCSD','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(16,10,'asasda','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(17,10,'','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(18,10,'','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(19,10,'xxx','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(20,10,'asa','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(21,10,'adas','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(22,10,'','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(23,10,'asdda','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(24,10,'','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(25,10,'asdas','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(26,11,'pedro','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(27,11,'juan','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(28,11,'andres','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com'),(29,11,'hola chao','MCMxOTptZWV0aW5nX01UQXhPVFF3WlRZdFpEUTJPQzAwT1RoaUxXRXpaRFl0Tm1aaFltRTNZek0yT1RkakB0aHJlYWQudjIjMA== ','rommgt@vwz1s.onmicrosoft.com');
/*!40000 ALTER TABLE `open_answers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-03 10:13:28
